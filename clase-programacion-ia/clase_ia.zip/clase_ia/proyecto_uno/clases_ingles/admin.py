from django.contrib import admin
from .models import Interes, Student

admin.site.register(Interes)
admin.site.register(Student)
